const firebaseConfig = {
    apiKey: "AIzaSyC41hRenJUD-ARaYG24_tkMDIqHLIsSN1A",
    authDomain: "flood-watch-online.firebaseapp.com",
    databaseURL: "https://flood-watch-online-default-rtdb.firebaseio.com",
    projectId: "flood-watch-online",
    storageBucket: "flood-watch-online.appspot.com",
    messagingSenderId: "54279732837",
    appId: "1:54279732837:web:a88d010a45958d48a4108c"
};
firebase.initializeApp(firebaseConfig);

function signout() {
    firebase.auth().signOut().then(() => {
        console.log("out");
        window.location.href = "index.html";
    }).catch((error) => {
        alert(error)
    });
}

