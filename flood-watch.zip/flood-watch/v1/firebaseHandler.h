#include <ESP8266WiFi.h>
#include <Firebase_ESP_Client.h>
#include <addons/RTDBHelper.h>
#include <addons/TokenHelper.h>
#define WIFI_SSID "esp-wifi"
#define WIFI_PASSWORD "admin1234"
#define DATABASE_URL "https://flood-watch-online-default-rtdb.firebaseio.com"
#define API_KEY "AIzaSyC41hRenJUD-ARaYG24_tkMDIqHLIsSN1A"
#define USER_EMAIL "esp@admin.com"
#define USER_PASSWORD "admin1234"
FirebaseData fbdo;
FirebaseAuth auth;
FirebaseConfig config;

#define MY_NTP_SERVER "at.pool.ntp.org"
#define MY_TZ "PST-8"
#include <time.h>
time_t now;
tm tm;


struct DateTime {
  String date;
  String time;
};

DateTime getFormattedDateTime() {
  DateTime dateTime;

  time(&now);
  localtime_r(&now, &tm);
  dateTime.date = String(((tm.tm_mon + 1) < 10 ? "0" : "")) + String(tm.tm_mon + 1) + "-" + String(((tm.tm_mday < 10) ? "0" : "")) + String(tm.tm_mday) + "-" + String(tm.tm_year + 1900);
  dateTime.time = String(tm.tm_hour < 10 ? "0" : "") + String(tm.tm_hour) + ":" + String(tm.tm_min < 10 ? "0" : "") + String(tm.tm_min) + ":" + String(tm.tm_sec < 10 ? "0" : "") + String(tm.tm_sec);

  Serial.print("date: ");
  Serial.print(dateTime.date);
  Serial.print("\ttime: ");
  Serial.println(dateTime.time);

  return dateTime;
}


void fbSetup() {
  Serial.begin(115200);

  WiFi.begin(WIFI_SSID, WIFI_PASSWORD);
  Serial.println();
  Serial.println();
  Serial.print("Connecting to Wi-Fi");
  while (WiFi.status() != WL_CONNECTED) {
    Serial.print(".");
    delay(300);
  }
  Serial.println();
  Serial.print("Connected with IP: ");
  Serial.println(WiFi.localIP());
  Serial.println();

  delay(2000);

  Serial.printf("Firebase Client v%s\n\n", FIREBASE_CLIENT_VERSION);

  config.api_key = API_KEY;
  auth.user.email = USER_EMAIL;
  auth.user.password = USER_PASSWORD;
  config.database_url = DATABASE_URL;
  config.token_status_callback = tokenStatusCallback;

  fbdo.setBSSLBufferSize(2048, 2048);
  fbdo.setResponseSize(2048);
  Firebase.begin(&config, &auth);

  Firebase.reconnectWiFi(true);
  Firebase.setDoubleDigits(5);
  config.timeout.serverResponse = 10 * 1000;

  delay(1000);
  configTime(MY_TZ, MY_NTP_SERVER);
}

void sendData(const String &data) {

  String parts[5];
  int partIndex = 0;
  int lastIndex = 0;
  String delimiter = "x";

  for (int i = 0; i < data.length(); i++) {
    if (data.charAt(i) == delimiter.charAt(0)) {
      parts[partIndex] = data.substring(lastIndex, i);
      lastIndex = i + 1;
      partIndex++;
    }
  }
  parts[partIndex] = data.substring(lastIndex);

  // Assign the parts to variables
  String d1 = parts[0];
  String d2 = parts[1];
  String s1 = parts[2];
  String s2 = parts[3];
  String s3 = parts[4];
  String iden = parts[5];

  s1 = (s1 == "0") ? "1" : "0";
  s2 = (s2 == "0") ? "1" : "0";
  s3 = (s3 == "0") ? "1" : "0";

  int level = atoi(s1.c_str()) + atoi(s2.c_str()) + atoi(s3.c_str());

  Serial.print(d1);
  Serial.print("\t");
  Serial.print(d2);
  Serial.print("\t");
  Serial.print(s1);
  Serial.print("\t");
  Serial.print(s2);
  Serial.print("\t");
  Serial.print(s3);
  Serial.print("\t");
  Serial.print(iden);
  Serial.print("\t");
  Serial.print(level);
  Serial.println("");

  DateTime formattedDateTime = getFormattedDateTime();
  String curr_date = String(formattedDateTime.date);
  String curr_time = String(formattedDateTime.time);

  FirebaseJson json;
  json.add("date", curr_date);
  json.add("time", curr_time);
  json.add("water_level_01", d1);
  json.add("water_level_02", d2);
  json.add("s1", s1);
  json.add("s2", s2);
  json.add("s3", s3);

  json.add("level", level);

  if (Firebase.RTDB.updateNode(&fbdo, "/latest", &json)) {
    Serial.println(fbdo.dataPath());
    Serial.println(fbdo.dataType());
    Serial.println(fbdo.jsonString());
  } else {
    Serial.println(fbdo.errorReason());
  }

  if (iden == "1") {
    if (Firebase.RTDB.pushJSON(&fbdo, "/data", &json)) {
      Serial.println(fbdo.dataPath());
      Serial.println(fbdo.dataType());
      Serial.println(fbdo.jsonString());
    } else {
      Serial.println(fbdo.errorReason());
    }
  }
}
